# SWAI Backend (Ready to deploy on Railway)

Node.js backend with Stripe integration.